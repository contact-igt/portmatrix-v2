import Header from "@/components/Header";
import Hero from "@/components/Hero";
import TrustBar from "@/components/TrustBar";
import Services from "@/components/Services";
import ChinaSourcing from "@/components/ChinaSourcing";
import ProcessTimeline from "@/components/ProcessTimeline";
import WhyChooseUs from "@/components/WhyChooseUs";
import ContactCTA from "@/components/ContactCTA";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="relative">
      <Header />
      <Hero />
      <TrustBar />
      <Services />
      <ChinaSourcing />
      <ProcessTimeline />
      <WhyChooseUs />
      <ContactCTA />
      <Footer />
    </main>
  );
}
