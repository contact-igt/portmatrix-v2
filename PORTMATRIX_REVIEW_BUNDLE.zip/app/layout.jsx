import { Space_Grotesk, Inter, Space_Mono } from "next/font/google";
import "./globals.css";

const display = Space_Grotesk({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-display",
  display: "swap",
});

const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-body",
  display: "swap",
});

const mono = Space_Mono({
  subsets: ["latin"],
  weight: ["400", "700"],
  variable: "--font-mono",
  display: "swap",
});

export const metadata = {
  title: "PORTMATRIX Logistics — Excellence in Compliance",
  description:
    "Government Licensed Customs Broker in Chennai. End-to-end customs clearance, Export-Import, China sourcing, MOOWR, DGFT, SEZ & FTWZ consultancy across India.",
  keywords: [
    "customs broker Chennai",
    "customs clearance India",
    "EXIM consultant",
    "China import sourcing",
    "DGFT consultancy",
    "MOOWR warehousing",
    "ICEGATE filing",
  ],
  openGraph: {
    title: "PORTMATRIX Logistics — Excellence in Compliance",
    description:
      "Government Licensed Customs Broker. End-to-end EXIM clearance, China sourcing & trade consultancy.",
    type: "website",
  },
};

export const viewport = {
  themeColor: "#2E3192",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={`${display.variable} ${body.variable} ${mono.variable}`}
    >
      <body className="font-sans antialiased">{children}</body>
    </html>
  );
}
