"use client";

import { motion } from "framer-motion";
import { Plane, Users, ShieldCheck, Package, Globe2, ArrowRight } from "lucide-react";
import { fadeUp, stagger, inView } from "@/lib/animations";

const POINTS = [
  { icon: Users, title: "Permanent China team", desc: "Chinese-speaking staff and a local intelligence cell that finds the right factory, not a wrong supplier." },
  { icon: ShieldCheck, title: "Factory inspection & QC", desc: "Goods inspected, re-packed and verified before they ever board a vessel." },
  { icon: Package, title: "FCL & LCL delivery", desc: "Full or part container loads, door-to-door, with one agreed service charge and zero hidden costs." },
  { icon: Plane, title: "Canton Fair support", desc: "Visa, ticketing, hotels and guided factory visits for the bi-annual Guangzhou trade fair." },
];

export default function ChinaSourcing() {
  return (
    <section
      id="china"
      className="relative scroll-mt-20 overflow-hidden bg-navy py-20 text-white sm:py-28"
    >
      <div className="bg-blueprint-dark pointer-events-none absolute inset-0 opacity-60" />
      <div className="pointer-events-none absolute -right-32 top-0 h-[420px] w-[420px] rounded-full bg-brandred/20 blur-[130px]" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2">
        <motion.div variants={stagger} {...inView}>
          <motion.span
            variants={fadeUp}
            className="kicker mb-3 flex items-center gap-2 text-brandred-300"
          >
            <span className="h-px w-6 bg-current" /> The gateway to China
          </motion.span>
          <motion.h2
            variants={fadeUp}
            className="font-display text-3xl font-bold leading-tight tracking-tight sm:text-[2.5rem]"
          >
            Source from China and cut purchase cost by 30–40%
          </motion.h2>
          <motion.p variants={fadeUp} className="mt-4 max-w-lg text-white/70">
            Our trade link to China dates back to 1974. Against the myth, China
            produces very high-quality goods — we help you source, negotiate,
            inspect and deliver them to your door, with utmost transparency.
          </motion.p>

          <motion.div variants={fadeUp} className="mt-8">
            <a
              href="#contact"
              className="group inline-flex items-center gap-2 rounded-full bg-brandred px-6 py-3.5 text-sm font-semibold text-white shadow-glow transition-all hover:bg-brandred-600"
            >
              Plan a China import
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
          </motion.div>

          <motion.div
            variants={fadeUp}
            className="mt-8 flex items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-4"
          >
            <Globe2 className="h-9 w-9 shrink-0 text-brandred-300" />
            <p className="text-sm text-white/75">
              <span className="font-semibold text-white">5 decades</span> of trade
              with Hong Kong &amp; China — from gemstones in 1974 to full-scale
              sourcing today.
            </p>
          </motion.div>
        </motion.div>

        <motion.div variants={stagger} {...inView} className="grid gap-4 sm:grid-cols-2">
          {POINTS.map((p) => {
            const Icon = p.icon;
            return (
              <motion.div
                key={p.title}
                variants={fadeUp}
                whileHover={{ y: -4 }}
                className="rounded-2xl border border-white/10 bg-white/[0.06] p-5 backdrop-blur-sm transition-colors hover:bg-white/[0.1]"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brandred/15 text-brandred-300">
                  <Icon className="h-5 w-5" />
                </div>
                <h3 className="mt-4 font-display text-base font-bold">{p.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-white/65">{p.desc}</p>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
