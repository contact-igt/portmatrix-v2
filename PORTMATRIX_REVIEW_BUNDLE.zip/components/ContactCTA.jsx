"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Globe, Send, CheckCircle2 } from "lucide-react";
import { fadeUp, stagger, inView } from "@/lib/animations";

const SERVICE_OPTIONS = [
  "Customs Clearance",
  "Export–Import",
  "China Sourcing",
  "MOOWR / SEZ / DGFT",
];

export default function ContactCTA() {
  const [form, setForm] = useState({ name: "", phone: "", service: SERVICE_OPTIONS[0], message: "" });
  const [sent, setSent] = useState(false);

  const update = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  // Front-end demo only — wire this to your CRM / email endpoint.
  const submit = () => {
    if (!form.name || !form.phone) return;
    setSent(true);
    setTimeout(() => setSent(false), 4000);
    setForm({ name: "", phone: "", service: SERVICE_OPTIONS[0], message: "" });
  };

  return (
    <section id="contact" className="relative scroll-mt-20 bg-paper py-20 sm:py-28">
      <div className="bg-blueprint pointer-events-none absolute inset-0 opacity-60" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="overflow-hidden rounded-[28px] border border-hairline bg-white shadow-lift lg:grid lg:grid-cols-[1fr_1.1fr]">
          {/* left: details */}
          <motion.div
            variants={stagger}
            {...inView}
            className="relative bg-navy p-8 text-white sm:p-10"
          >
            <div className="bg-blueprint-dark pointer-events-none absolute inset-0 opacity-50" />
            <div className="relative">
              <motion.span variants={fadeUp} className="kicker text-brandred-300">
                Get in touch
              </motion.span>
              <motion.h2
                variants={fadeUp}
                className="mt-3 font-display text-3xl font-bold leading-tight sm:text-4xl"
              >
                Let's clear your next shipment together
              </motion.h2>
              <motion.p variants={fadeUp} className="mt-4 text-white/70">
                Tell us what you're moving. We'll get back with a transparent plan
                and an agreed service charge — no hidden costs.
              </motion.p>

              <motion.ul variants={stagger} className="mt-9 space-y-5">
                <motion.li variants={fadeUp} className="flex gap-4">
                  <MapPin className="h-5 w-5 shrink-0 text-brandred-300" />
                  <span className="text-sm leading-relaxed text-white/80">
                    Wavoo Mansion Annex, No. 105-B, I Floor,
                    <br />
                    58/39 Rajaji Salai, Chennai 600 001, Tamil Nadu
                  </span>
                </motion.li>
                <motion.li variants={fadeUp} className="flex gap-4">
                  <Phone className="h-5 w-5 shrink-0 text-brandred-300" />
                  <div className="text-sm text-white/80">
                    <a href="tel:+914448517879" className="block hover:text-white">
                      +91 44 4851 7879
                    </a>
                    <a href="tel:+919359352345" className="block hover:text-white">
                      +91 935 935 2345 · 95857 90909
                    </a>
                  </div>
                </motion.li>
                <motion.li variants={fadeUp} className="flex gap-4">
                  <Mail className="h-5 w-5 shrink-0 text-brandred-300" />
                  <a
                    href="mailto:info@portmatrix.in"
                    className="text-sm text-white/80 hover:text-white"
                  >
                    info@portmatrix.in
                  </a>
                </motion.li>
                <motion.li variants={fadeUp} className="flex gap-4">
                  <Globe className="h-5 w-5 shrink-0 text-brandred-300" />
                  <a
                    href="https://www.portmatrix.in"
                    className="text-sm text-white/80 hover:text-white"
                  >
                    www.portmatrix.in
                  </a>
                </motion.li>
              </motion.ul>
            </div>
          </motion.div>

          {/* right: form */}
          <motion.div variants={fadeUp} {...inView} className="p-8 sm:p-10">
            <h3 className="font-display text-xl font-bold text-ink">Request a quote</h3>
            <p className="mt-1.5 text-sm text-slatey">
              We typically respond within one business day.
            </p>

            <div className="mt-6 space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <Field label="Your name">
                  <input
                    value={form.name}
                    onChange={update("name")}
                    placeholder="Full name"
                    className="input"
                  />
                </Field>
                <Field label="Phone">
                  <input
                    value={form.phone}
                    onChange={update("phone")}
                    placeholder="+91"
                    className="input"
                  />
                </Field>
              </div>

              <Field label="Service needed">
                <div className="flex flex-wrap gap-2">
                  {SERVICE_OPTIONS.map((opt) => (
                    <button
                      key={opt}
                      type="button"
                      onClick={() => setForm((f) => ({ ...f, service: opt }))}
                      className={`rounded-full border px-3.5 py-2 text-xs font-semibold transition-colors ${
                        form.service === opt
                          ? "border-navy bg-navy text-white"
                          : "border-hairline bg-paper text-slatey hover:border-navy/40"
                      }`}
                    >
                      {opt}
                    </button>
                  ))}
                </div>
              </Field>

              <Field label="Shipment details">
                <textarea
                  value={form.message}
                  onChange={update("message")}
                  rows={3}
                  placeholder="Commodity, origin/destination, container type…"
                  className="input resize-none"
                />
              </Field>

              <button
                onClick={submit}
                className="group flex w-full items-center justify-center gap-2 rounded-full bg-brandred px-6 py-3.5 text-sm font-semibold text-white shadow-card transition-all hover:bg-brandred-600 hover:shadow-lift"
              >
                {sent ? (
                  <>
                    <CheckCircle2 className="h-4 w-4" /> Request received
                  </>
                ) : (
                  <>
                    Send request
                    <Send className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </>
                )}
              </button>
              <p className="text-center text-xs text-slatey">
                Prefer to talk? Call{" "}
                <a href="tel:+914448517879" className="font-semibold text-navy">
                  +91 44 4851 7879
                </a>
              </p>
            </div>
          </motion.div>
        </div>
      </div>

      <style jsx>{`
        :global(.input) {
          width: 100%;
          border-radius: 0.85rem;
          border: 1px solid #e2e6f2;
          background: #f6f7fc;
          padding: 0.7rem 0.9rem;
          font-size: 0.875rem;
          color: #0d102e;
          outline: none;
          transition: border-color 0.2s, box-shadow 0.2s;
        }
        :global(.input:focus) {
          border-color: #2e3192;
          box-shadow: 0 0 0 3px rgba(46, 49, 146, 0.12);
          background: #fff;
        }
        :global(.input::placeholder) {
          color: #9aa1bb;
        }
      `}</style>
    </section>
  );
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-semibold uppercase tracking-wide text-slatey">
        {label}
      </span>
      {children}
    </label>
  );
}
