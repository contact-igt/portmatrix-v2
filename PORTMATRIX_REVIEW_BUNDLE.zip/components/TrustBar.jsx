"use client";

import { motion } from "framer-motion";
import Counter from "./Counter";
import { fadeUp, stagger, inView } from "@/lib/animations";

const STATS = [
  { to: 1996, label: "Licensed broker since", mono: true, plain: true },
  { to: 1974, label: "China trade roots from", mono: true, plain: true },
  { to: 40, suffix: "%", label: "Avg. China cost saved" },
  { to: 100, suffix: "%", label: "Pan-India clearance" },
];

const MARQUEE = [
  "Customs Brokers Regulations 2018",
  "ICEGATE e-filing",
  "Bill of Entry & Shipping Bill",
  "HS Code classification",
  "DGFT consultancy",
  "MOOWR · Section 65",
  "SEZ & FTWZ registration",
  "Advance Authorisation · EPCG",
  "RoDTEP · Duty Drawback",
  "China sourcing since 1974",
];

export default function TrustBar() {
  return (
    <section className="relative border-y border-hairline bg-white">
      <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 lg:py-14">
        <motion.div
          variants={stagger}
          {...inView}
          className="grid grid-cols-2 gap-6 lg:grid-cols-4"
        >
          {STATS.map((s) => (
            <motion.div key={s.label} variants={fadeUp} className="text-center sm:text-left">
              <div className="font-display text-3xl font-bold text-navy sm:text-4xl">
                {s.plain ? (
                  <Counter to={s.to} plain />
                ) : (
                  <Counter to={s.to} suffix={s.suffix || ""} />
                )}
              </div>
              <p className="mt-1.5 text-sm font-medium text-slatey">{s.label}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* scrolling credential marquee */}
      <div className="relative overflow-hidden border-t border-hairline bg-paper py-3.5">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-16 bg-gradient-to-r from-paper to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-16 bg-gradient-to-l from-paper to-transparent" />
        <div className="flex w-max animate-marquee gap-8 pr-8">
          {[...MARQUEE, ...MARQUEE].map((item, i) => (
            <span
              key={i}
              className="flex items-center gap-3 whitespace-nowrap font-mono text-xs uppercase tracking-wide text-slatey"
            >
              {item}
              <span className="h-1 w-1 rounded-full bg-brandred" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
