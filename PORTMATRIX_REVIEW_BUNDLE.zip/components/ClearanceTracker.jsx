"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileText,
  Stamp,
  Calculator,
  ScanLine,
  ShieldCheck,
  Truck,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Ship,
} from "lucide-react";

// Each mode is a real PORTMATRIX workflow.
const MODES = {
  import: {
    label: "Import",
    ref: "BOE-IN-4827193",
    route: "Shenzhen, CN → Chennai Port, IN",
    eta: "2 days",
    stages: [
      { icon: FileText, title: "Documents received", note: "Invoice, packing list, B/L" },
      { icon: Stamp, title: "Bill of Entry filed", note: "Submitted on ICEGATE" },
      { icon: Calculator, title: "Duty assessed", note: "BCD + IGST + SWS computed" },
      { icon: ScanLine, title: "Examination", note: "Customs inspection cleared" },
      { icon: ShieldCheck, title: "Out of Charge", note: "OoC granted" },
      { icon: Truck, title: "Delivered", note: "Last-mile to warehouse" },
    ],
  },
  export: {
    label: "Export",
    ref: "SB-EX-9051482",
    route: "Chennai, IN → Rotterdam, NL",
    eta: "On schedule",
    stages: [
      { icon: FileText, title: "Export docs collected", note: "Invoice, PO, LUT" },
      { icon: Stamp, title: "Shipping Bill filed", note: "Generated in ICEGATE" },
      { icon: Calculator, title: "Scheme verified", note: "RoDTEP / Drawback checked" },
      { icon: ScanLine, title: "Examination", note: "Cargo stuffing inspected" },
      { icon: ShieldCheck, title: "LEO granted", note: "Let Export Order issued" },
      { icon: Ship, title: "Vessel departed", note: "B/L generated" },
    ],
  },
  china: {
    label: "China Sourcing",
    ref: "CN-SRC-2024-118",
    route: "Guangzhou → Door delivery, IN",
    eta: "End to end",
    stages: [
      { icon: FileText, title: "Supplier sourced", note: "Right factory identified" },
      { icon: Calculator, title: "Price negotiated", note: "30–40% cost reduction" },
      { icon: ScanLine, title: "Factory inspection", note: "QC by local team" },
      { icon: Ship, title: "FCL / LCL booked", note: "Vessel arranged" },
      { icon: ShieldCheck, title: "Customs cleared", note: "Licensed broker handling" },
      { icon: Truck, title: "Door delivered", note: "Hassle-free to your dock" },
    ],
  },
};

export default function ClearanceTracker() {
  const [mode, setMode] = useState("import");
  const [active, setActive] = useState(2);
  const [playing, setPlaying] = useState(true);
  const timer = useRef(null);

  const data = MODES[mode];
  const total = data.stages.length;
  const pct = Math.round(((active + 1) / total) * 100);

  // auto-advance the pipeline
  useEffect(() => {
    if (!playing) return;
    timer.current = setInterval(() => {
      setActive((a) => (a + 1) % total);
    }, 1900);
    return () => clearInterval(timer.current);
  }, [playing, total, mode]);

  // reset stage index when switching modes
  useEffect(() => {
    setActive(2);
  }, [mode]);

  const reset = () => {
    setActive(0);
    setPlaying(true);
  };

  return (
    <div className="relative w-full">
      {/* floating accent badge */}
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5 }}
        className="absolute -left-3 -top-3 z-20 hidden items-center gap-1.5 rounded-full bg-brandred px-3 py-1.5 text-xs font-semibold text-white shadow-glow sm:flex"
      >
        <span className="relative flex h-2 w-2">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-white/70" />
          <span className="relative inline-flex h-2 w-2 rounded-full bg-white" />
        </span>
        Live clearance
      </motion.div>

      <div className="overflow-hidden rounded-3xl border border-hairline bg-white shadow-lift">
        {/* widget header */}
        <div className="flex items-center justify-between gap-3 border-b border-hairline bg-navy px-5 py-4">
          <div className="min-w-0">
            <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-white/55">
              Shipment reference
            </p>
            <p className="truncate font-mono text-sm font-bold text-white">
              {data.ref}
            </p>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPlaying((p) => !p)}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white transition-colors hover:bg-white/20"
              aria-label={playing ? "Pause" : "Play"}
            >
              {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </button>
            <button
              onClick={reset}
              className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/10 text-white transition-colors hover:bg-white/20"
              aria-label="Restart"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* mode tabs */}
        <div className="flex gap-1 p-2">
          {Object.entries(MODES).map(([key, m]) => (
            <button
              key={key}
              onClick={() => setMode(key)}
              className={`relative flex-1 rounded-xl px-2 py-2 text-xs font-semibold transition-colors sm:text-sm ${
                mode === key ? "text-white" : "text-slatey hover:text-navy"
              }`}
            >
              {mode === key && (
                <motion.span
                  layoutId="trackTab"
                  className="absolute inset-0 rounded-xl bg-navy"
                  transition={{ type: "spring", duration: 0.5 }}
                />
              )}
              <span className="relative z-10">{m.label}</span>
            </button>
          ))}
        </div>

        {/* route + progress */}
        <div className="px-5 pb-1 pt-2">
          <div className="flex items-center justify-between gap-2 text-xs text-slatey">
            <span className="truncate font-medium">{data.route}</span>
            <span className="shrink-0 font-mono text-navy">ETA {data.eta}</span>
          </div>
          <div className="mt-3 h-2 w-full overflow-hidden rounded-full bg-mist">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-navy to-brandred"
              animate={{ width: `${pct}%` }}
              transition={{ type: "spring", damping: 22, stiffness: 120 }}
            />
          </div>
          <div className="mt-1.5 flex justify-between font-mono text-[10px] text-slatey">
            <span>Cleared {pct}%</span>
            <span>
              Stage {active + 1}/{total}
            </span>
          </div>
        </div>

        {/* stage list */}
        <div className="space-y-1 px-3 pb-4 pt-2">
          {data.stages.map((s, i) => {
            const Icon = s.icon;
            const done = i < active;
            const current = i === active;
            return (
              <button
                key={s.title}
                onClick={() => {
                  setActive(i);
                  setPlaying(false);
                }}
                className={`flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left transition-colors ${
                  current ? "bg-navy-50" : "hover:bg-paper"
                }`}
              >
                <div
                  className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg transition-colors ${
                    current
                      ? "bg-brandred text-white"
                      : done
                      ? "bg-navy text-white"
                      : "bg-mist text-slatey"
                  }`}
                >
                  {done ? (
                    <CheckCircle2 className="h-5 w-5" />
                  ) : (
                    <Icon className="h-[18px] w-[18px]" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p
                    className={`truncate text-sm font-semibold ${
                      current ? "text-navy" : done ? "text-ink" : "text-slatey"
                    }`}
                  >
                    {s.title}
                  </p>
                  <p className="truncate text-xs text-slatey">{s.note}</p>
                </div>
                <AnimatePresence>
                  {current && (
                    <motion.span
                      initial={{ opacity: 0, scale: 0.6 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.6 }}
                      className="shrink-0 rounded-full bg-brandred/10 px-2 py-0.5 font-mono text-[10px] font-bold uppercase tracking-wide text-brandred"
                    >
                      In progress
                    </motion.span>
                  )}
                </AnimatePresence>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
