"use client";

import { motion } from "framer-motion";
import {
  FileCheck2,
  Gauge,
  Handshake,
  Eye,
  TrendingUp,
  GraduationCap,
} from "lucide-react";
import SectionHeading from "./SectionHeading";
import { fadeUp, stagger, inView } from "@/lib/animations";

const STRENGTHS = [
  { icon: FileCheck2, title: "Error-free documentation", desc: "Absence of even one requirement can mean penalties or seizure. We get the paperwork right the first time." },
  { icon: Gauge, title: "Faster clearance turnaround", desc: "Due diligence and electronic filing that keeps your cargo moving without avoidable delays." },
  { icon: Handshake, title: "Strong PGA liaison", desc: "Good standing with Customs and Partner Government Agencies for speedy releases." },
  { icon: Eye, title: "Total transparency", desc: "No hidden charges — only an agreed service fee. You always know what you're paying for." },
];

const INTEL = [
  "Import Penetration Index",
  "Trade Intensity Index",
  "Export Propensity Index",
  "SHI & RHI interpretation",
  "Competitor analysis",
  "Right Regional Trade Agreements",
];

export default function WhyChooseUs() {
  return (
    <section id="why" className="relative scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-[1fr_0.9fr] lg:gap-16">
          {/* left: strengths */}
          <div>
            <SectionHeading
              kicker="Why PORTMATRIX"
              title="Compliance is not a checkbox. It's our whole discipline."
              intro="Customs compliance is a structured legal obligation under the Customs Act and allied laws. We treat every shipment with the rigor that demands."
            />

            <motion.div
              variants={stagger}
              {...inView}
              className="mt-10 grid gap-4 sm:grid-cols-2"
            >
              {STRENGTHS.map((s) => {
                const Icon = s.icon;
                return (
                  <motion.div
                    key={s.title}
                    variants={fadeUp}
                    className="rounded-2xl border border-hairline bg-white p-5 shadow-card"
                  >
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-brandred/10 text-brandred">
                      <Icon className="h-5 w-5" />
                    </div>
                    <h3 className="mt-4 font-display text-base font-bold text-ink">
                      {s.title}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slatey">{s.desc}</p>
                  </motion.div>
                );
              })}
            </motion.div>
          </div>

          {/* right: MD card + intelligence */}
          <motion.div variants={stagger} {...inView} className="flex flex-col gap-5">
            {/* MD credibility */}
            <motion.div
              variants={fadeUp}
              className="relative overflow-hidden rounded-3xl border border-hairline bg-navy p-7 text-white shadow-lift"
            >
              <div className="bg-blueprint-dark pointer-events-none absolute inset-0 opacity-50" />
              <div className="relative">
                <div className="flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-brandred-300">
                  <GraduationCap className="h-4 w-4" /> Led by the Managing Director
                </div>
                <p className="mt-4 font-display text-2xl font-bold leading-snug">
                  Mr. Rahim Iyaz
                </p>
                <p className="mt-1 text-sm text-white/70">
                  Government Licensed Customs Broker · M.Com, MBA, M.Phil ·
                  PGDIBO
                </p>
                <p className="mt-4 text-sm leading-relaxed text-white/70">
                  Vintage foreign-trade experience since 1996 across the Maldives,
                  Singapore, China, Hong Kong, UAE, Saudi Arabia and Sri Lanka — and
                  an authorised export-training resource person for MSME, FIEO,
                  EDII-TN and TNAPEx.
                </p>
              </div>
            </motion.div>

            {/* EXIM intelligence */}
            <motion.div
              variants={fadeUp}
              className="rounded-3xl border border-hairline bg-white p-7 shadow-card"
            >
              <div className="flex items-center gap-2 text-brandred">
                <TrendingUp className="h-5 w-5" />
                <span className="kicker">EXIM market intelligence</span>
              </div>
              <h3 className="mt-3 font-display text-xl font-bold text-ink">
                Decide with data, not guesswork
              </h3>
              <p className="mt-2 text-sm text-slatey">
                Beyond clearance, we scan global markets and interpret the trade
                indices that tell you where — and what — to sell.
              </p>
              <div className="mt-5 flex flex-wrap gap-2">
                {INTEL.map((tag) => (
                  <span
                    key={tag}
                    className="rounded-full bg-navy-50 px-3 py-1.5 font-mono text-[11px] text-navy"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
