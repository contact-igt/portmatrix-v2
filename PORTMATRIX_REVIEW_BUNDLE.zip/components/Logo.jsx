// Faithful recreation of the PORTMATRIX logo: a 2x2 square mark
// (navy / red / red / navy) + "PortMatrix" wordmark with the red "M".

export default function Logo({ variant = "dark", showTagline = true, className = "" }) {
  const navy = "#2E3192";
  const red = "#ED1B24";
  // wordmark colours flip on dark backgrounds for "Port" only
  const portColor = variant === "light" ? "#FFFFFF" : navy;

  return (
    <div className={`flex items-center gap-2.5 ${className}`} aria-label="PortMatrix">
      {/* 2x2 square mark */}
      <svg
        width="34"
        height="34"
        viewBox="0 0 34 34"
        fill="none"
        className="shrink-0"
        aria-hidden="true"
      >
        <rect x="0" y="0" width="15" height="15" rx="3.2" fill={navy} />
        <rect x="19" y="0" width="15" height="15" rx="3.2" fill={red} />
        <rect x="0" y="19" width="15" height="15" rx="3.2" fill={red} />
        <rect x="19" y="19" width="15" height="15" rx="3.2" fill={navy} />
      </svg>

      <div className="flex flex-col leading-none">
        <span className="font-display text-xl font-bold tracking-tight">
          <span style={{ color: portColor }}>Port</span>
          <span style={{ color: red }}>Matrix</span>
        </span>
        {showTagline && (
          <span
            className="mt-0.5 font-mono text-[9px] tracking-[0.18em] uppercase"
            style={{ color: variant === "light" ? "rgba(255,255,255,0.7)" : "#5B6178" }}
          >
            Excellence in Compliance
          </span>
        )}
      </div>
    </div>
  );
}
