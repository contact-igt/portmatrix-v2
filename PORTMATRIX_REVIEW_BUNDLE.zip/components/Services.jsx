"use client";

import { motion } from "framer-motion";
import {
  Stamp,
  ArrowLeftRight,
  Container,
  Warehouse,
  FileSignature,
  Building2,
  ArrowUpRight,
} from "lucide-react";
import SectionHeading from "./SectionHeading";
import { fadeUp, stagger, inView } from "@/lib/animations";

const SERVICES = [
  {
    icon: Stamp,
    title: "Customs Clearance",
    desc: "Licensed clearing agent under CBLR 2018 — Bill of Entry, Shipping Bill, examinations and Out-of-Charge across every Indian port.",
    tag: "Core",
  },
  {
    icon: ArrowLeftRight,
    title: "Export–Import Clearance",
    desc: "Full documentary compliance (CCR), correct HS codes and accurate duty calculation so cargo moves without delays or seizure.",
    tag: "EXIM",
  },
  {
    icon: Container,
    title: "China Import Sourcing",
    desc: "End-to-end sourcing, factory inspection and FCL/LCL delivery — with a permanent Chinese-speaking team since 1974.",
    tag: "Since 1974",
  },
  {
    icon: Warehouse,
    title: "MOOWR Warehousing",
    desc: "Section 65 bonded-warehouse setup — import raw materials and capital goods with full duty deferment, no export obligation.",
    tag: "Duty deferment",
  },
  {
    icon: FileSignature,
    title: "DGFT Consultancy",
    desc: "Advance Authorisation, EPCG, RoDTEP and incentive schemes — structured for maximum, compliant duty savings.",
    tag: "Schemes",
  },
  {
    icon: Building2,
    title: "SEZ & FTWZ Registration",
    desc: "Set up in duty-free zones treated as foreign territory — built for exporters who need scale and simplified compliance.",
    tag: "Setup",
  },
];

export default function Services() {
  return (
    <section id="services" className="relative scroll-mt-20 py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <SectionHeading
            kicker="Core services"
            title="Everything between the factory and the final mile"
            intro="One licensed partner for clearance, sourcing, warehousing and trade consultancy — so you never juggle five vendors for one shipment."
          />
          <motion.a
            variants={fadeUp}
            {...inView}
            href="#contact"
            className="hidden shrink-0 items-center gap-1.5 rounded-full border border-navy/20 px-5 py-3 text-sm font-semibold text-navy transition-colors hover:bg-navy-50 md:inline-flex"
          >
            Discuss your shipment <ArrowUpRight className="h-4 w-4" />
          </motion.a>
        </div>

        <motion.div
          variants={stagger}
          {...inView}
          className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-3"
        >
          {SERVICES.map((s) => {
            const Icon = s.icon;
            return (
              <motion.div
                key={s.title}
                variants={fadeUp}
                whileHover={{ y: -6 }}
                transition={{ type: "spring", stiffness: 300, damping: 20 }}
                className="group relative overflow-hidden rounded-2xl border border-hairline bg-white p-6 shadow-card transition-shadow hover:shadow-lift"
              >
                {/* hover accent bar */}
                <span className="absolute inset-x-0 top-0 h-1 origin-left scale-x-0 bg-gradient-to-r from-navy to-brandred transition-transform duration-300 group-hover:scale-x-100" />

                <div className="flex items-start justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy-50 text-navy transition-colors group-hover:bg-navy group-hover:text-white">
                    <Icon className="h-6 w-6" />
                  </div>
                  <span className="rounded-full bg-paper px-2.5 py-1 font-mono text-[10px] uppercase tracking-wide text-slatey">
                    {s.tag}
                  </span>
                </div>

                <h3 className="mt-5 font-display text-xl font-bold text-ink">
                  {s.title}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-slatey">{s.desc}</p>

                <div className="mt-5 flex items-center gap-1.5 text-sm font-semibold text-navy opacity-0 transition-opacity group-hover:opacity-100">
                  Learn more <ArrowUpRight className="h-4 w-4" />
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
