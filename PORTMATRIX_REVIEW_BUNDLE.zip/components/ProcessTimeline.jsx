"use client";

import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Download, Upload } from "lucide-react";
import SectionHeading from "./SectionHeading";

const FLOWS = {
  import: [
    { t: "Receive shipping documents", d: "We collect the B/L, invoice and packing list from the importer." },
    { t: "File Bill of Entry on ICEGATE", d: "Electronic declaration filed for home consumption or warehousing." },
    { t: "Calculate customs duties", d: "BCD, IGST, SWS, ADD and cess computed against the correct HS code." },
    { t: "Coordinate inspection", d: "We arrange examination and respond to any customs queries." },
    { t: "Get Out of Charge", d: "Duty advised and paid; cargo released with OoC." },
    { t: "Arrange last-mile transport", d: "Container moved to the importer's warehouse." },
  ],
  export: [
    { t: "Collect export documents", d: "Invoice, packing list, PO and LUT/Bond gathered." },
    { t: "Classify & check compliance", d: "HS code classification and PGA compliance verified." },
    { t: "File Shipping Bill", d: "Bill of Export generated in ICEGATE with scheme verification." },
    { t: "Cargo stuffing & examination", d: "Goods stuffed, moved to CFS/ICD and examined." },
    { t: "Let Export Order (LEO)", d: "LEO approved; container loaded or handed to airline." },
    { t: "Vessel departure & B/L", d: "Bill of Lading generated; export documents guided to your bank." },
  ],
};

export default function ProcessTimeline() {
  const [flow, setFlow] = useState("import");
  const steps = FLOWS[flow];

  return (
    <section id="process" className="relative scroll-mt-20 bg-white py-20 sm:py-28">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHeading
          align="center"
          kicker="How it works"
          title="A clearance workflow you can actually see"
          intro="Every shipment follows a defined, transparent sequence. Switch between import and export to see exactly where PORTMATRIX steps in."
        />

        {/* toggle */}
        <div className="mt-10 flex justify-center">
          <div className="relative inline-flex rounded-full border border-hairline bg-paper p-1">
            {[
              { key: "import", label: "Import", icon: Download },
              { key: "export", label: "Export", icon: Upload },
            ].map((f) => {
              const Icon = f.icon;
              return (
                <button
                  key={f.key}
                  onClick={() => setFlow(f.key)}
                  className={`relative z-10 flex items-center gap-2 rounded-full px-6 py-2.5 text-sm font-semibold transition-colors ${
                    flow === f.key ? "text-white" : "text-slatey hover:text-navy"
                  }`}
                >
                  {flow === f.key && (
                    <motion.span
                      layoutId="flowToggle"
                      className="absolute inset-0 -z-10 rounded-full bg-navy"
                      transition={{ type: "spring", duration: 0.5 }}
                    />
                  )}
                  <Icon className="h-4 w-4" /> {f.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* timeline */}
        <div className="relative mx-auto mt-14 max-w-4xl">
          {/* vertical spine */}
          <div className="absolute left-[19px] top-2 bottom-2 w-px bg-gradient-to-b from-navy via-navy/40 to-brandred sm:left-1/2 sm:-translate-x-1/2" />

          <AnimatePresence mode="wait">
            <motion.ol
              key={flow}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {steps.map((s, i) => (
                <motion.li
                  key={s.t}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.08 }}
                  className={`relative flex items-start gap-5 sm:w-1/2 ${
                    i % 2 === 0
                      ? "sm:ml-0 sm:pr-12 sm:text-right sm:flex-row-reverse"
                      : "sm:ml-auto sm:pl-12"
                  }`}
                >
                  {/* node */}
                  <span className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-navy font-mono text-sm font-bold text-white shadow-card">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <div className="rounded-2xl border border-hairline bg-white p-4 shadow-card">
                    <h3 className="font-display text-base font-bold text-ink">{s.t}</h3>
                    <p className="mt-1 text-sm text-slatey">{s.d}</p>
                  </div>
                </motion.li>
              ))}
            </motion.ol>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
