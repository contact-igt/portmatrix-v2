import Logo from "./Logo";
import { ArrowUpRight } from "lucide-react";

const COLS = [
  {
    title: "Services",
    links: [
      "Customs Clearance",
      "Export–Import",
      "China Sourcing",
      "MOOWR Warehousing",
      "DGFT Consultancy",
      "SEZ & FTWZ",
    ],
  },
  {
    title: "Company",
    links: ["About PORTMATRIX", "Our MD", "RIIT Training", "Canton Fair", "Contact"],
  },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-ink text-white">
      <div className="bg-blueprint-dark pointer-events-none absolute inset-0 opacity-40" />
      <div className="relative mx-auto max-w-7xl px-5 py-14 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo variant="light" />
            <p className="mt-5 max-w-xs text-sm leading-relaxed text-white/60">
              PORTMATRIX Logistics Pvt. Ltd. — a Government Licensed Customs
              Broking company delivering end-to-end EXIM clearance and trade
              consultancy across India.
            </p>
            <p className="mt-5 font-mono text-xs uppercase tracking-wide text-white/40">
              Allied: Regional Institute of International Trade (RIIT)
            </p>
          </div>

          {COLS.map((col) => (
            <div key={col.title}>
              <h4 className="font-mono text-xs uppercase tracking-[0.16em] text-white/50">
                {col.title}
              </h4>
              <ul className="mt-4 space-y-2.5">
                {col.links.map((l) => (
                  <li key={l}>
                    <a
                      href="#"
                      className="text-sm text-white/70 transition-colors hover:text-white"
                    >
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div>
            <h4 className="font-mono text-xs uppercase tracking-[0.16em] text-white/50">
              Reach us
            </h4>
            <ul className="mt-4 space-y-2.5 text-sm text-white/70">
              <li>
                <a href="tel:+914448517879" className="hover:text-white">
                  +91 44 4851 7879
                </a>
              </li>
              <li>
                <a href="mailto:info@portmatrix.in" className="hover:text-white">
                  info@portmatrix.in
                </a>
              </li>
              <li>Chennai 600 001, Tamil Nadu</li>
            </ul>
            <a
              href="#contact"
              className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-white/20"
            >
              Get a quote <ArrowUpRight className="h-4 w-4" />
            </a>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-white/45 sm:flex-row">
          <p>© {new Date().getFullYear()} PORTMATRIX Logistics Pvt. Ltd. All rights reserved.</p>
          <p className="font-mono uppercase tracking-wide">Excellence in Compliance</p>
        </div>
      </div>
    </footer>
  );
}
