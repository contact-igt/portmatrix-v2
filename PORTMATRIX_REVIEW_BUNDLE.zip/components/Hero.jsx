"use client";

import { motion } from "framer-motion";
import { ArrowRight, ShieldCheck, BadgeCheck } from "lucide-react";
import ClearanceTracker from "./ClearanceTracker";
import { fadeUp, stagger } from "@/lib/animations";

const PARTNERS = [
  "ICEGATE",
  "DGFT",
  "FSSAI",
  "BIS",
  "CDSCO",
  "Plant Quarantine",
  "RBI / FEMA",
  "GST / IEC",
];

export default function Hero() {
  return (
    <section
      id="top"
      className="relative overflow-hidden bg-paper pt-28 pb-16 sm:pt-32 lg:pb-24"
    >
      {/* blueprint backdrop + glow */}
      <div className="bg-blueprint pointer-events-none absolute inset-0 opacity-70" />
      <div className="pointer-events-none absolute -right-40 -top-24 h-[480px] w-[480px] rounded-full bg-brandred/10 blur-[120px]" />
      <div className="pointer-events-none absolute -left-40 top-40 h-[420px] w-[420px] rounded-full bg-navy/10 blur-[120px]" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:gap-10">
        {/* Left — copy */}
        <motion.div variants={stagger} initial="hidden" animate="show">
          <motion.div
            variants={fadeUp}
            className="inline-flex items-center gap-2 rounded-full border border-navy/15 bg-white px-3.5 py-1.5 shadow-sm"
          >
            <BadgeCheck className="h-4 w-4 text-brandred" />
            <span className="kicker text-navy">
              Govt. Licensed Customs Broker · Since 1996
            </span>
          </motion.div>

          <motion.h1
            variants={fadeUp}
            className="mt-5 font-display text-[2.5rem] font-bold leading-[1.05] tracking-tight text-ink sm:text-6xl"
          >
            Move cargo across borders,{" "}
            <span className="relative whitespace-nowrap">
              <span className="relative z-10 text-navy">without the friction</span>
              <svg
                className="absolute -bottom-2 left-0 z-0 h-3 w-full"
                viewBox="0 0 300 12"
                preserveAspectRatio="none"
                aria-hidden="true"
              >
                <path
                  d="M2 8 C 80 2, 220 2, 298 8"
                  stroke="#ED1B24"
                  strokeWidth="3"
                  fill="none"
                  strokeLinecap="round"
                />
              </svg>
            </span>
          </motion.h1>

          <motion.p
            variants={fadeUp}
            className="mt-6 max-w-xl text-base leading-relaxed text-slatey sm:text-lg"
          >
            PORTMATRIX handles end-to-end customs clearance for exporters,
            importers and vessel agents — with the accuracy, speed and
            transparency that complex EXIM compliance demands. One partner,
            every Customs Station in India.
          </motion.p>

          <motion.div variants={fadeUp} className="mt-8 flex flex-wrap items-center gap-3">
            <a
              href="#contact"
              className="group flex items-center gap-2 rounded-full bg-navy px-6 py-3.5 text-sm font-semibold text-white shadow-card transition-all hover:bg-navy-700 hover:shadow-lift"
            >
              Get a free consultation
              <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </a>
            <a
              href="#services"
              className="flex items-center gap-2 rounded-full border border-navy/20 bg-white px-6 py-3.5 text-sm font-semibold text-navy transition-colors hover:border-navy hover:bg-navy-50"
            >
              Explore services
            </a>
          </motion.div>

          {/* compliance partner strip */}
          <motion.div variants={fadeUp} className="mt-10">
            <div className="flex items-center gap-2 text-xs font-medium text-slatey">
              <ShieldCheck className="h-4 w-4 text-navy" />
              Compliant across every PGA
            </div>
            <div className="mt-3 flex flex-wrap gap-x-5 gap-y-2 font-mono text-[11px] uppercase tracking-wide text-slatey/80">
              {PARTNERS.map((p) => (
                <span key={p}>{p}</span>
              ))}
            </div>
          </motion.div>
        </motion.div>

        {/* Right — interactive widget */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          <ClearanceTracker />
        </motion.div>
      </div>
    </section>
  );
}
